package presentation;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Random;

/**
 * Panel of the Level 3
 * Juan Esteban Rodriguez- Sara Gonzalez
 */
public class LevelThree extends JFrame {

    private JLabel background;
    private Image floorImg;
    private Image iceBlockImg;
    
    private final int BLOCK_SIZE = 40;
    
    private int[][] iceBlockPositions;
    private final int NUM_ICE_BLOCKS = 20;
    
    /**
     * Constructor
    */
    public LevelThree() {
        setTitle("Level 3");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loadImages();
        generateRandomIceBlocks();
        prepareElements();

        setVisible(true);
    }

    /**
     * Method for load the images to put in the game screen
    */
    private void loadImages() {
        floorImg = new ImageIcon(getClass().getResource("/resources/floor.jpg")).getImage();
        iceBlockImg = new ImageIcon(getClass().getResource("/resources/iceBlock.jpg")).getImage();
    }
    /**
     * Method for generate different ice blocks randomly
    */
    private void generateRandomIceBlocks() {
        iceBlockPositions = new int[NUM_ICE_BLOCKS][2];
        Random random = new Random();
        
        for (int i = 0; i < NUM_ICE_BLOCKS; i++) {
            iceBlockPositions[i][0] = random.nextInt(20) * BLOCK_SIZE;
            iceBlockPositions[i][1] = random.nextInt(15) * BLOCK_SIZE;
        }
    }

    /**
     * Method for prepare the actions of those elements before mentioned and pass to the other screen
    */
    private void prepareElements() {
        File file = new File("resources/board.jpeg");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon);
        background.setBounds(0, 0, 800, 600);
        add(background);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        drawFloor(g);
        drawIceBlocks(g);
    }
    /**
     * Method for control all the elements
     * @param g graphics for show the result
    */
    private void drawFloor(Graphics g) {
        for (int y = 0; y < getHeight(); y += 40) {
            for (int x = 0; x < getWidth(); x += 40) {
                g.drawImage(floorImg, x, y, 40, 40, this);
            }
        }
    }
    
    /**
     * Method for draw the ice blocks
     * @param g graphics for show the result
    */
    private void drawIceBlocks(Graphics g) {
        for (int i = 0; i < NUM_ICE_BLOCKS; i++) {
            g.drawImage(iceBlockImg, iceBlockPositions[i][0], iceBlockPositions[i][1], BLOCK_SIZE, BLOCK_SIZE, this);
        }
    }

}


//asi pongo los tipos de baldosas en el nivel
// Ejemplo dentro de Level.load() o un método similar
//public void load() {
    // Crear una fogata en (5,3)
  //  map.setTipoCelda(new Position(5, 3), Map.FOGATA);

    // Crear una baldosa caliente en (2,6)
    //map.setTipoCelda(new Position(2, 6), Map.BALDOSA_CALIENTE);

    // Colocar algunos muros:
    //map.setTipoCelda(new Position(0, 0), Map.MURO);
//}


//asi se derrite el hielo
//public void crearHieloEn(Position p) {
    // Si es baldosa caliente, el hielo se derrite inmediatamente
  //  if (map.esBaldosaCaliente(p)) {
        // Opcional: podrías crear el Ice solo para animación y luego quitarlo;
        // aquí simplemente dejas la baldosa sin hielo
    //    map.clearCell(p);  // sigue siendo baldosa caliente en el grid si quieres
      //  return;
    //}

    // En celdas normales sí queda el bloque de hielo
    //Ice bloque = new Ice(true, p);
   // map.placeIce(bloque);
//}

//asi se mata al jugador
//Position posJugador = player.getPosition();

//if (map.esFogata(posJugador)) {
    // aquí haces lo que tu diseño pida:
    // por ejemplo, reiniciar nivel o restar una vida
  //  nivelPerdido();
//}

//asi creo con imagenes
// igual que ya haces con el iglú, piso, helado
//public class LevelOne extends JPanel {

  //  private Image imgFogata;
    //private Image imgBaldosaCaliente;

    //private void cargarImagenes() {
      //  imgFogata = new ImageIcon("resources/fogata.png").getImage();
        //imgBaldosaCaliente = new ImageIcon("resources/baldosa_caliente.png").getImage();
        // aquí ya cargas piso, iglú, jugador, frutas, etc.
   // }
//}

//nuevo enemigo
package domain;

import javax.swing.ImageIcon;

/**
 * Enemigo genérico de ejemplo.
 * Extiende Enemy y define su propio movimiento en move().
 */
public class NuevoEnemigo extends Enemy {

    private ImageIcon sprite;

    public NuevoEnemigo(Position position) {
        super(position);
        this.sprite = new ImageIcon("resources/nuevoEnemigo.png");
    }

    public ImageIcon getSprite() {
        return sprite;
    }

    @Override
    public void move(Map map, Position iceCreamPos) {
        int x = position.getX();
        int y = position.getY();

        int newX = x;
        int newY = y;

        // EJEMPLOS de movimiento (elige uno o combina):
        // 1) Perseguir al jugador en X
        if (iceCreamPos.getX() > x) newX++;
        else if (iceCreamPos.getX() < x) newX--;

        // 2) O solo moverse arriba/abajo:
        // if (iceCreamPos.getY() > y) newY++;
        // else if (iceCreamPos.getY() < y) newY--;

        Position next = new Position(newX, newY);

        // Evitar muros
        if (map.isBlocked(next)) {
            return;
        }

        // Si quieres que rompa hielo:
        // if (map.isBreakableIce(next)) {
        //     map.removeIce(next);
        //     return;
        // }

        position.setX(newX);
        position.setY(newY);
    }
}

//nueva casilla 
// En Map
//public static final int HIELO_RESBALOSO = 6;

//public boolean esHieloResbaloso(Position p) {
  //  int x = p.getX(), y = p.getY();
    //if (x < 0 || x >= width || y < 0 || y >= height) return false;
    //return grid[y][x] == HIELO_RESBALOSO;
//}

//deslizarse dos casillas
private void moverJugador(int dx, int dy) {
    Position actual = player.getPosition();
    Position destino = new Position(actual.getX() + dx, actual.getY() + dy);

    // validar límites y muros como ya haces...

    player.setPosition(destino);

    // Si cae en hielo resbaloso, avanzar una casilla extra
    if (map.esHieloResbaloso(destino)) {
        Position extra = new Position(destino.getX() + dx, destino.getY() + dy);
        if (!map.isBlocked(extra)) {
            player.setPosition(extra);
        }
    }
//} baldosa que acelera al jugador y trampa que lo regresa una casilla
//nueva fruta
// En FruitType (enum)
SANDIA(200, "Sandía");

// En Fruit
public void aplicarEfecto(BadDopoCream juego, IceCream jugador) {
    switch (type) {
        case BANANA:
            juego.sumarPuntos(type.getPoints());
            break;
        case SANDIA:
            // Ejemplo: dar velocidad extra o invencibilidad
            jugador.activarVelocidad(5000); // 5 segundos
            juego.sumarPuntos(type.getPoints());
            break;
        // etc.
    }
}

//mover cualquier cosa
Position destino = new Position(x + dx, y + dy);
if (estaLibre(destino)) {
    // mover jugador / enemigo
}
//otro
private boolean invencible;
private long finInvencible;

public void activarInvencibilidad(long duracionMs) {
    invencible = true;
    finInvencible = System.currentTimeMillis() + duracionMs;
}

public void actualizarEstados() {
    if (invencible && System.currentTimeMillis() >= finInvencible) {
        invencible = false;
    }
}

public boolean estaInvencible() {
    return invencible;
}


