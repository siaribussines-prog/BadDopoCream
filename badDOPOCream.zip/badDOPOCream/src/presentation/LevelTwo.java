package presentation;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

/**
 * Panel of the Level 2
 * Juan Esteban Rodriguez- Sara Gonzalez
 */

public class LevelTwo extends JFrame {

    private JLabel background;
    private Image floorImg;
    private Image iceBlockImg;
    private List<Fruit> fruits;
    
    private final int BLOCK_SIZE = 40;
    
    private int[][] iceBlockPositions;
    private final int NUM_ICE_BLOCKS = 20;

    /**
     * Constructor
    */
    public LevelTwo() {
        setTitle("Level 2");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loadImages();
        generateRandomIceBlocks();
        prepareElements();

        setVisible(true);
    }
    
    /**
     * Method for load the images to put in the game screen
    */
    private void loadImages() {
        floorImg = new ImageIcon(getClass().getResource("/resources/floor.jpg")).getImage();
        iceBlockImg = new ImageIcon(getClass().getResource("/resources/iceBlock.jpg")).getImage();
    }
    
    /**
     * Method for generate different ice blocks randomly
    */
    private void generateRandomIceBlocks() {
        iceBlockPositions = new int[NUM_ICE_BLOCKS][2];
        Random random = new Random();
        
        for (int i = 0; i < NUM_ICE_BLOCKS; i++) {
            iceBlockPositions[i][0] = random.nextInt(20) * BLOCK_SIZE;
            iceBlockPositions[i][1] = random.nextInt(15) * BLOCK_SIZE;
        }
    }

    /**
     * Method for prepare the actions of those elements before mentioned and pass to the other screen
    */
    private void prepareElements() {
        File file = new File("resources/board.jpeg");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon);
        background.setBounds(0, 0, 800, 600);
        add(background);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        drawFloor(g);
        drawIceBlocks(g);
    }
    /**
     * Method for control all the elements
     * @param g graphics for show the result
    */
    private void drawFloor(Graphics g) {
        for (int y = 0; y < getHeight(); y += 40) {
            for (int x = 0; x < getWidth(); x += 40) {
                g.drawImage(floorImg, x, y, 40, 40, this);
            }
        }
    }

  

    private void initLevel() {

        fruits = new ArrayList<>();

        // Crear cerezas en posiciones que están libres
        fruits.add(new Cherry(4, 6, this, ROWS, COLS));
        fruits.add(new Cherry(4, 13, this, ROWS, COLS));
        fruits.add(new Cherry(8, 9, this, ROWS, COLS));
        fruits.add(new Cherry(12, 5, this, ROWS, COLS));
        fruits.add(new Cherry(12, 14, this, ROWS, COLS));

        // Aquí pondrás más frutas: uva, banana, cactus, piña, etc.
    }

    
    /**
     * Method for draw the ice blocks
     * @param g graphics for show the result
    */
    private void drawIceBlocks(Graphics g) {
        for (int i = 0; i < NUM_ICE_BLOCKS; i++) {
            g.drawImage(iceBlockImg, iceBlockPositions[i][0], iceBlockPositions[i][1], BLOCK_SIZE, BLOCK_SIZE, this);
        }
    }

}