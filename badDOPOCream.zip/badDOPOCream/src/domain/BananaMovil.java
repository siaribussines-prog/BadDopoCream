package domain;

public class BananaMovil extends Fruit {

    private int dx;
    private int dy;

    public BananaMovil(Position position) {
        super(position); // llamas al constructor de Fruit
        this.dx = 1; // se mueve hacia la derecha al inicio
        this.dy = 0;
    }

    /**
     * Mueve la banana una casilla y rebota en los muros.
     */
    public void move(Map map) {
        int x = getPosition().getX();
        int y = getPosition().getY();

        int newX = x + dx;
        int newY = y + dy;

        Position next = new Position(newX, newY);

        // Si hay muro, invertimos dirección (rebote)
        if (map.isBlocked(next)) {
            dx = -dx;
            dy = -dy;
            return;
        }

        getPosition().setX(newX);
        getPosition().setY(newY);
    }}

    // en el nivel
    BananaMovil b = new BananaMovil(new Position(4, 2));fruits.add(b);
package domain;

    public class BananaVenenosa extends Fruit {

        public BananaVenenosa(Position position) {
            super(position);
        }

        /**
         * Efecto al ser comida.
         */
        public void onEaten(BadDopoCream juego, IceCream jugador) {
            juego.jugadorMuere(jugador); // implementas este método en tu lógica
        }
    }

    // en level
    Iterator<Fruit> it = fruits.iterator();while(it.hasNext())
    {
    Fruit f = it.next();
    if (mismaPos(f.getPosition(), player.getPosition())) {

        if (f instanceof BananaVenenosa) {
            ((BananaVenenosa) f).onEaten(juego, player);
        } else {
            // frutas normales: solo suman puntos
            juego.addScore(100);
        }

        it.remove();
    }
}
