package domain;

public enum FruitType {
    GRAPE(50),
    BANANA(100),
    CHERRY(150),
    PINEAPPLE(200),
    CACTUS(250);

    private final int points;

    FruitType(int points) {
        this.points = points;
    }

    public int getPoints() {
        return points;
    }
}
