package domain;

public class saveFlavor {
    public static Flavor selectedFlavor = Flavor.Flavor;
}
