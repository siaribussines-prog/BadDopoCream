package domain;

public class Fruit {

    private Position position;
    private FruitType type;
    private boolean collected;

    public Fruit(Position position, FruitType type) {
        this.position = position;
        this.type = type;
        this.collected = false;
    }

    public Position getPosition() {
        return position;
    }

    public FruitType getType() {
        return type;
    }

    public boolean isCollected() {
        return collected;
    }

    public void collect() {
        this.collected = true;
    }

    public int getPoints() {
        return type.getPoints();
    }
}

