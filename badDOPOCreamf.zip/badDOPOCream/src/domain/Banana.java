package domain;

import javax.swing.*;

public class Banana {

    private int row;
    private int col;
    private ImageIcon sprite;

    public Banana(int row, int col) {
        this.row = row;
        this.col = col;
        this.sprite = new ImageIcon("recursos/platano.png");
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public ImageIcon getSprite() {
        return sprite;
    }
}