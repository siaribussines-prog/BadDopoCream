package domain;

import domain.Flavor;

public class saveFlavor {
    public static Flavor selectedFlavor;
}
