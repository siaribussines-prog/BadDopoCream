package domain;

/**
 * Regla: los bloques de hielo creados sobre la baldosa caliente se derriten de inmediato.
 *
 * Versión mínima solo para que compile en el proyecto actual.
 */
public class BaldosaCaliente {   // por ahora sin implements Obstaculo

    // Usa Position en vez de Posicion
    private final Position posicion;

    /**
     * Crea una baldosa caliente en una posición.
     *
     * @param posicion posición de la baldosa (0/1-based según tu Position).
     */
    public BaldosaCaliente(Position posicion) {
        this.posicion = posicion;
    }

    /**
     * Obtiene la posición de la baldosa caliente.
     */
    public Position getPosicion() {
        return posicion;
    }

    /**
     * Indica si la baldosa caliente bloquea movimiento.
     * De momento siempre false.
     */
    public boolean bloqueaMovimiento() {
        return false;
    }

    /**
     * Lógica al entrar el helado.
     * Se deja vacío para no depender de clases Nivel/Helado antiguas.
     */
    public void alEntrarHelado(Object nivel, Object helado) {
        // TODO: adaptar cuando tengas clases Nivel y Helado nuevas
    }

    /**
     * Al crear hielo encima.
     * Devuelve false para indicar que el hielo no permanece.
     */
    public boolean alCrearHieloEncima(Object nivel) {
        return false;
    }

    /**
     * Actualización por tick.
     */
    public void actualizarUnTick(Object nivel) {
        // sin lógica por ahora
    }
}
