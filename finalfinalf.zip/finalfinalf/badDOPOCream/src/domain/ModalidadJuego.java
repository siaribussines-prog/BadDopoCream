package z;

public enum ModalidadJuego {
    Player,
    PvsP,
    PvsM,
    MvsM
}
