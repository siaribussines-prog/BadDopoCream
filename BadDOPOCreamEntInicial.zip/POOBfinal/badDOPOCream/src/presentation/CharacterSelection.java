package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Selection of the flavors (Vainilla, Chocolate, Strawberry)
 * Juan Esteban Rodriguez- Sara Gonzalez
 */

public class CharacterSelection extends JFrame {

    private JButton btnChocolate;
    private JButton btnVainilla;
    private JButton btnStrawberry;
    private JButton btnPlay;
    private JButton btnBack;
    private JLabel background;

    public CharacterSelection() {
        setTitle("Seleccione su Personaje");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        prepareElements();
        prepareActions();

        setVisible(true);
    }
    /**
     * Method to convert a picture as a button
     * @param path to get the route of the pictures
     * @param x,y to put the picture with the coordinates adjusted pof the GUI
     * @param width,height to focus the picture to a standard size
    */
    private JButton createImageButton(String path, int x, int y, int width, int height) {
        ImageIcon icon = new ImageIcon(path);
        JButton button = new JButton(icon);
        button.setBounds(x, y, width, height);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    /**
     * Method for prepare all elements necessary to the mode selection
    */
    private void prepareElements() {

        File file = new File("resources/backgr.png");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon){
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = bgIcon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };

        btnChocolate = createImageButton("resources/Chocolate.jpg", 120, 160, 150, 150);
        btnStrawberry = createImageButton("resources/Fresa.jpg", 290, 150, 150, 150); 
        btnVainilla = createImageButton("resources/Vainilla.jpg", 460, 170, 150, 150); 
        btnPlay = createImageButton("resources/play.jpg", 200, 380, 100, 40);
        btnBack = createImageButton("resources/back.jpg", 200, 450, 200, 60);

        add(btnChocolate);
        add(btnStrawberry);
        add(btnVainilla);
        add(btnPlay);
        add(btnBack);

        background.setBounds(0, 0, getWidth(), getHeight());
        add(background);
        
    }
    
    /**
     * Method for prepare the actions of those elements before mentioned and pass to the other screen
    */
    private void prepareActions() {

        btnChocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelSelection();
                dispose();
            }
        });

        btnStrawberry.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelSelection();
                dispose();
            }
        });

        btnVainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelSelection();
                dispose();
            }
        });


        btnPlay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelSelection();
                dispose();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ModeSelection();
                dispose();
            }
        });
    }
}

